#!/bin/bash
cd "$(dirname "$0")/modules"
exec python3 unbrick.py "$@"
