@echo off
setlocal
cd /d "%~dp0"

set "PY="
where py >nul 2>&1 && set "PY=py"
if not defined PY (
    where python >nul 2>&1 && set "PY=python"
)
if not defined PY (
    echo Python was not found. Install Python 3 from https://python.org,
    echo tick "Add to PATH" during setup, then run this again.
    pause
    exit /b 1
)

%PY% -c "import serial" >nul 2>&1
if errorlevel 1 (
    echo Installing pyserial...
    %PY% -m pip install -r requirements.txt
)

cd modules
%PY% unbrick.py %*
pause
