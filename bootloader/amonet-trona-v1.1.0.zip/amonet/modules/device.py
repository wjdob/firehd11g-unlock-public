import glob
import sys
import time

import serial
import serial.tools.list_ports
from logger import log

BAUD = 115200
TIMEOUT = 5
MTK_VID = 0x0E8D


def _open_serial(port):
    last = None
    for _ in range(20):
        try:
            return serial.Serial(port, BAUD, timeout=TIMEOUT)
        except (OSError, serial.SerialException) as exc:
            last = exc
            time.sleep(0.4)
    raise last


def serial_ports():
    listed = list(serial.tools.list_ports.comports())
    mtk = {
        port.device for port in listed if port.vid == MTK_VID and port.device
    }
    if mtk:
        return mtk
    if sys.platform.startswith('linux'):
        return set(glob.glob('/dev/ttyACM*'))
    if sys.platform.startswith('darwin'):
        return set(glob.glob('/dev/cu.usbmodem*'))
    if sys.platform.startswith('win'):
        return {
            port.device
            for port in listed
            if port.vid is not None and port.device
        }
    raise EnvironmentError('unsupported platform')


def reacquire(prev, timeout):
    log('Waiting for device')
    end = time.monotonic() + timeout
    while prev in serial_ports():
        if time.monotonic() > end:
            raise RuntimeError('no device')
        time.sleep(0.25)
    while True:
        ports = serial_ports()
        if ports:
            port = sorted(ports)[0]
            log('Found port = {}'.format(port))
            return port
        if time.monotonic() > end:
            raise RuntimeError('no device')
        time.sleep(0.25)


class Device:
    def __init__(self, port=None):
        self.dev = None
        self.port = port
        if port:
            self.dev = _open_serial(port)

    def find(self, wait_new=False, timeout=None):
        if self.dev:
            return self

        log('Waiting for device')
        old = serial_ports()
        if not wait_new and old:
            self.port = sorted(old)[0]
        else:
            end = time.monotonic() + timeout if timeout else None
            while True:
                added = serial_ports() - old
                if added:
                    self.port = sorted(added)[0]
                    break
                if end and time.monotonic() > end:
                    raise RuntimeError('no device')
                old &= serial_ports()
                time.sleep(0.25)

        log('Found port = {}'.format(self.port))
        self.dev = _open_serial(self.port)
        return self

    def handshake(self, cmd='METAMETA'):
        c = b''
        end = time.monotonic() + 20
        while c != b'Y':
            c = self.dev.read(1)
            if not c and time.monotonic() > end:
                raise RuntimeError('no READY')
        self.dev.reset_input_buffer()
        if not isinstance(cmd, bytes):
            cmd = cmd.encode()
        log('Preloader ready, sending {}'.format(cmd.decode()))
        self.dev.write(cmd)

    def write(self, data):
        return self.dev.write(data)

    def read(self, size=1):
        return self.dev.read(size)

    def drain(self):
        self.dev.reset_input_buffer()

    def close(self):
        if self.dev:
            try:
                self.dev.flush()
            except Exception:
                pass
            try:
                self.dev.close()
            except Exception:
                pass
            self.dev = None

    def transact(self, frame, overall=6, quiet=0.3, until=None):
        self.dev.reset_input_buffer()
        self.dev.timeout = 0.2
        self.dev.write(frame)

        out = bytearray()
        start = time.monotonic()
        end = start + overall
        last = None
        while time.monotonic() < end:
            chunk = self.dev.read(4096)
            if chunk:
                out.extend(chunk)
                last = time.monotonic()
                if until and until(bytes(out)):
                    break
            elif last and time.monotonic() - last >= quiet:
                break
            elif last is None and time.monotonic() - start >= 2:
                break
        return bytes(out)
