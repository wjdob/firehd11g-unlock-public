import struct
import time

import serial
from device import serial_ports as _ports
from logger import log

BAUD = 115200
TIMEOUT = 5
MAGIC = 0xF00DD00D
DA_ADDR = 0x40200000
MAX_BLOCKS_DEFAULT = 64
RETRIES = 8
EMMC_TIMEOUT = 2.0
RPMB_TIMEOUT = 10


def _p32(x):
    return struct.pack('>I', x)


class PLDevice:
    def __init__(self, port=None):
        self.dev = None
        self.max_blocks = MAX_BLOCKS_DEFAULT
        if port:
            self.dev = serial.Serial(port, BAUD, timeout=TIMEOUT)

    def find(self):
        if self.dev:
            return
        log('Waiting for device')
        while True:
            for port in sorted(_ports()):
                try:
                    self.dev = serial.Serial(port, BAUD, timeout=TIMEOUT)
                except (OSError, serial.SerialException):
                    continue
                log('Found port {}'.format(port))
                return
            time.sleep(0.1)

    def _check(self, got, want):
        if got != want:
            raise RuntimeError(
                'protocol mismatch, want {} got {}'.format(
                    want.hex(), got.hex()
                )
            )

    def _wb(self, byte):
        self.dev.write(byte)
        return self.dev.read()

    def _echo(self, val, size=1):
        data = val if isinstance(val, bytes) else val.to_bytes(size, 'big')
        self.dev.write(data)
        self._check(self.dev.read(len(data)), data)

    def read_exact(self, size):
        out = bytearray()
        while len(out) < size:
            chunk = self.dev.read(size - len(out))
            if not chunk:
                raise RuntimeError(
                    'read fail ({} of {})'.format(len(out), size)
                )
            out += chunk
        return bytes(out)

    def handshake(self):
        while self._wb(b'\xa0') != b'\x5f':
            self.dev.flushInput()
            self.dev.flushOutput()
        self.dev.flushInput()
        self.dev.flushOutput()
        self._check(self._wb(b'\x0a'), b'\xf5')
        self._check(self._wb(b'\x50'), b'\xaf')
        self._check(self._wb(b'\x05'), b'\xfa')

    def send_da(self, addr, data):
        self._echo(0xD7)
        self._echo(addr, 4)
        self._echo(len(data), 4)
        self._echo(0, 4)
        self._check(self.dev.read(2), b'\x00\x00')
        self.dev.write(data)
        self.dev.read(2)
        self._check(self.dev.read(2), b'\x00\x00')

    def jump_da(self, addr):
        self._echo(0xD5)
        self._echo(addr, 4)
        self._check(self.dev.read(2), b'\x00\x00')

    def wait_payload(self):
        hello = self.read_exact(4)
        if hello != b'\xb1\xb2\xb3\xb4':
            raise RuntimeError('bad payload hello {}'.format(hello.hex()))

    def command(self, cmd, *args, payload=None):
        pkt = b''.join(_p32(w) for w in (MAGIC, cmd) + args)
        if payload is not None:
            pkt += payload
        self.dev.write(pkt)

    def expect_ack(self):
        if self.read_exact(4) != b'\xd0\xd0\xd0\xd0':
            raise RuntimeError('device failure')

    def query_max_blocks(self):
        self.command(0x1005)
        self.max_blocks = struct.unpack('>I', self.read_exact(4))[0]
        if not 1 <= self.max_blocks <= 0x10000:
            raise RuntimeError('bogus block limit {}'.format(self.max_blocks))
        return self.max_blocks

    def emmc_switch(self, part):
        self.command(0x1002, part)

    def emmc_read(self, idx):
        self.dev.timeout = EMMC_TIMEOUT
        last = None
        for _ in range(RETRIES):
            try:
                self.dev.reset_input_buffer()
                self.command(0x1000, idx)
                return self.read_exact(0x200)
            except (OSError, serial.SerialException, RuntimeError) as exc:
                last = exc
                time.sleep(0.02)
        raise last

    def emmc_read_blocks(self, idx, blocks):
        out = bytearray()
        for i in range(blocks):
            out += self.emmc_read(idx + i)
        return bytes(out)

    def emmc_write(self, idx, data):
        self.dev.timeout = EMMC_TIMEOUT
        last = None
        for _ in range(RETRIES):
            try:
                self.dev.reset_input_buffer()
                self.command(0x1001, idx, payload=data)
                self.expect_ack()
                return
            except (OSError, serial.SerialException, RuntimeError) as exc:
                last = exc
                time.sleep(0.02)
        raise last

    def emmc_write_blocks(self, idx, data):
        for i in range(len(data) // 0x200):
            self.emmc_write(idx + i, data[i * 0x200 : (i + 1) * 0x200])

    def mem_read(self, addr, size):
        self.command(0x5000, addr, size)
        return self.read_exact(size)

    def reboot(self):
        self.command(0x3000)

    def rpmb_read(self, addr):
        self.dev.timeout = RPMB_TIMEOUT
        self.command(0x2000, addr)
        return self.read_exact(0x100)

    def rpmb_write(self, addr, data):
        self.dev.timeout = RPMB_TIMEOUT
        self.command(0x2001, addr, payload=data)
        return struct.unpack('>I', self.read_exact(4))[0]


def load_payload(dev, path):
    dev.find()
    log('Handshake')
    dev.handshake()
    with open(path, 'rb') as fin:
        data = fin.read()
    while len(data) % 4 != 0:
        data += b'\x00'
    log('Load pl-payload = 0x{:X} bytes'.format(len(data)))
    dev.send_da(DA_ADDR, data)
    dev.jump_da(DA_ADDR)
    dev.wait_payload()
    log('Payload up, max transfer {} blocks'.format(dev.query_max_blocks()))
