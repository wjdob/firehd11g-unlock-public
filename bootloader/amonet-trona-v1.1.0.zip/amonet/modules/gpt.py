import struct

BLOCK = 0x200
SIGNATURE = b'EFI PART'
HEADER = '<8sIIIIQQQQ16sQIII420x'
ENTRY = '<16s16sQQQ72s'


def parse(dev):
    hdr = struct.unpack(HEADER, dev.emmc_read(1))
    if hdr[0] != SIGNATURE:
        raise RuntimeError('no valid GPT header')
    part_lba, part_num, part_size = hdr[10], hdr[11], hdr[12]

    count = (part_num * part_size) // BLOCK
    table = b''
    while len(table) // BLOCK < count:
        done = len(table) // BLOCK
        run = min(dev.max_blocks, count - done)
        table += dev.emmc_read_blocks(part_lba + done, run)

    parts = {}
    for i in range(part_num):
        _, _, first, last, _, name = struct.unpack(
            ENTRY, table[i * part_size : (i + 1) * part_size]
        )
        if last == 0:
            continue
        parts[name.decode('utf-16le').rstrip('\x00')] = (
            first,
            last - first + 1,
        )
    return parts
