import os
import sys

import common
import gpt
import pl
from logger import log, progress

FIRMWARE = common.binpath()

PARTS = [
    ('trona-kaeru.bin', 'lk'),
    ('twrp.img', 'recovery'),
    ('tee.img', 'tee1'),
    ('spmfw.img', 'spmfw'),
    ('sspm.img', 'sspm_1'),
    ('cam_vpu1.img', 'cam_vpu1'),
    ('cam_vpu2.img', 'cam_vpu2'),
    ('cam_vpu3.img', 'cam_vpu3'),
]

RPMB_BLOCKS = 1


def _blocks(image):
    data = open(os.path.join(FIRMWARE, image), 'rb').read()
    if len(data) % 0x200 != 0:
        data += b'\x00' * (0x200 - len(data) % 0x200)
    return data


def flash_at(dev, image, start):
    data = _blocks(image)
    total = len(data) // 0x200
    log('Flashing {} ({} blocks)'.format(image, total))
    done = 0
    while done < total:
        run = min(dev.max_blocks, total - done)
        dev.emmc_write_blocks(
            start + done, data[done * 0x200 : (done + run) * 0x200]
        )
        done += run
        progress(done, total)


def boot_recovery(dev, parts):
    if 'misc' not in parts:
        log('no misc partition, skipping recovery flag')
        return
    start = parts['misc'][0]
    block = bytearray(dev.emmc_read(start))
    cmd = b'boot-recovery'
    block[0:32] = cmd + b'\x00' * (32 - len(cmd))
    dev.emmc_write(start, bytes(block))


def clear_rpmb(dev, count):
    zeros = b'\x00' * 0x100
    log('Clearing RPMB ({} block(s))'.format(count))
    cleared = 0
    for addr in range(count):
        result = dev.rpmb_write(addr, zeros)
        if result != 0:
            if sys.stdout.isatty() and cleared:
                sys.stdout.write('\n')
            log(
                'RPMB write failed at block {}, result 0x{:X}'.format(
                    addr, result
                )
            )
            break
        cleared += 1
        progress(cleared, count)
    log('Cleared {} block(s)'.format(cleared))


def main():
    dev = pl.PLDevice(sys.argv[1] if len(sys.argv) > 1 else None)
    pl.load_payload(dev, common.binpath('pl-payload.bin'))

    dev.emmc_switch(0)
    parts = gpt.parse(dev)
    for image, name in PARTS:
        if name not in parts:
            log('{} not in GPT, skipping'.format(name))
            continue
        flash_at(dev, image, parts[name][0])

    boot_recovery(dev, parts)

    clear_rpmb(dev, RPMB_BLOCKS)

    log('Rebooting...')
    dev.reboot()


if __name__ == '__main__':
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    main()
