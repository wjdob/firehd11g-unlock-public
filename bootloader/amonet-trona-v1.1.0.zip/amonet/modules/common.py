import hashlib
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BIN = os.path.join(ROOT, 'bin')

BANNER = r"""
               _             _
     ___  __ _(_)_   _  __ _| | ___   _
    / __|/ _` | | | | |/ _` | |/ / | | |
    \__ \ (_| | | |_| | (_| |   <| |_| |
    |___/\__,_|_|\__, |\__,_|_|\_\\__,_|
                 |___/
     by r0rt1z2, bengris32 and jackmthws
"""

DISCLAIMER = [
    'Unlock the bootloader of your Amazon Echo Show 8 (2nd Gen).',
    '',
    '  * If something goes wrong, the device can stop booting for good.',
    '  * It voids the warranty and will likely break OTA updates.',
    '  * It has nothing to do with Amazon.',
    '  * If you brick it, that is your problem, not ours :)',
]


def binpath(*parts):
    return os.path.join(BIN, *parts)


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def clear():
    subprocess.run('cls' if os.name == 'nt' else 'clear', shell=True)


def colors():
    off = {k: '' for k in ('red', 'green', 'yellow', 'magenta', 'cyan', 'reset')}
    if not sys.stdout.isatty() or os.environ.get('TERM') == 'dumb':
        return off
    if os.name == 'nt':
        try:
            import ctypes

            h = ctypes.windll.kernel32
            h.SetConsoleMode(h.GetStdHandle(-11), 7)
        except Exception:
            return off
    return {
        'red': '\033[31m',
        'green': '\033[32m',
        'yellow': '\033[33m',
        'magenta': '\033[35m',
        'cyan': '\033[36m',
        'reset': '\033[0m',
    }


def show_notice():
    clear()
    c = colors()
    print(c['magenta'] + BANNER.rstrip('\n'))
    print()
    for line in DISCLAIMER:
        print(c['yellow'] + line + c['reset'] if line else '')
    print()
    prompt = 'Unlock the bootloader? (Type "YES" to continue): '
    try:
        ans = input(prompt).strip()
    except EOFError:
        ans = 'YES'
    if ans != 'YES':
        print()
        print(c['yellow'] + '  Aborting.' + c['reset'])
        raise SystemExit(0)
    clear()
