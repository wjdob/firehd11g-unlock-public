import datetime
import sys

LOG = 'saiyaku.log'


def _write(s):
    line = '[{}] {}'.format(datetime.datetime.now(), s)
    with open(LOG, 'a', encoding='utf-8', errors='replace') as fout:
        fout.write(line + '\n')
    return line


def log(s):
    line = _write(s)
    try:
        print(line)
    except UnicodeEncodeError:
        print(line.encode('ascii', 'replace').decode('ascii'))


def log_quiet(s):
    _write(s)


def progress(done, total):
    if not sys.stdout.isatty():
        return
    width = 24
    frac = done / total if total else 1.0
    fill = int(width * frac)
    bar = '#' * fill + ' ' * (width - fill)
    sys.stdout.write('\r  [{}] {:3d}%'.format(bar, int(100 * frac)))
    if done >= total:
        sys.stdout.write('\n')
    sys.stdout.flush()
